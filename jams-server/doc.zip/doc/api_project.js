define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-06-05T16:15:02.609Z",
    "url": "http://apidocjs.com",
    "version": "0.23.0"
  }
});
